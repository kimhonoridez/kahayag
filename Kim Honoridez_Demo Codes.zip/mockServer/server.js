var express = require('express');
var fs = require('fs-extra');
var bodyParser = require('body-parser');

var app = express();

app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));

app.use(express.static(__dirname + '/'));

app.post('/custMgt/save', function (req, res) {
	var data = req.body;

    console.log("INSERT: " + data.toString());

    var custList = fs.readJsonSync('customerList.json');
    data.id = '' + 10000 + custList.length;
    custList.push(data);

	fs.writeJsonSync('customerList.json', custList);
	res.send('SUCCESS');
});

app.get('/custMgt/getCustList', function (req, res) {
    var params = req.query;
    var custList = fs.readJsonSync('customerList.json');

    var returnList = [];
    var fullname = "";

    custList.forEach(function (item) {
        var temp = {};

        if (params.name) {
            fullname = item.firstName + " " + item.lastName;
            temp.name = (fullname.toUpperCase().indexOf(params.name.toUpperCase()) >= 0);
        }

        if (params.referenceId) {
            console.log("" + item.id + " = " +  params.referenceId);
            temp.id = (item.id.indexOf(params.referenceId) >= 0);
        }

        var isOk = true;
        for (var key in temp) {
            if (!temp[key]) {
                isOk = false;
                break;
            }
        }

        if (isOk) {
            returnList.push(item);
        }
    });

    res.send(returnList);
});

app.listen(8000, function () {
	console.log("Listening to port 8000.");
});