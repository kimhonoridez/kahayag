/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    module.exports = function(grunt) {

        grunt.initConfig({
            clean: {
                build: ['dist']
            },
            copy: {
                vendors: {
                    files: [
                        // JS Files
                        {expand: true, cwd: 'bower_components/jquery/dist/', src: 'jquery.min.js', dest: 'dist/vendor/'},
                        {expand: true, cwd: 'bower_components/angular/', src: 'angular.min.js', dest: 'dist/vendor/'},
                        {expand: true, cwd: 'bower_components/angular-bootstrap/', src: 'ui-bootstrap-tpls.min.js', dest: 'dist/vendor/'},
                        {expand: true, cwd: 'bower_components/angular-cookies/', src: 'angular-cookies.min.js', dest: 'dist/vendor/'},
                        {expand: true, cwd: 'bower_components/angular-ui-router/release/', src: 'angular-ui-router.min.js', dest: 'dist/vendor/'},

                        // CSS Files
                        {expand: true, cwd: 'bower_components/bootstrap/dist/css/', src: 'bootstrap.css', dest: 'dist/vendor/'},
                        {expand: true, cwd: 'bower_components/font-awesome/css/', src: 'font-awesome.css', dest: 'dist/vendor/'},
                        {expand: true, cwd: 'bower_components/rdash-ui/dist/css', src: 'rdash.css', dest: 'dist/vendor/'},

                        // Fonts
                        {expand: true, cwd: 'bower_components/bootstrap/dist/fonts/', src: '**/*.{ttf,woff,eof,svg}', dest: 'dist/fonts/'},
                        {expand: true, cwd: 'bower_components/font-awesome/fonts/', src: '**/*.{ttf,woff,eof,svg}', dest: 'dist/fonts/'},
                        {expand: true, cwd: 'bower_components/rdash-ui/dist/fonts/', src: '**/*.{ttf,woff,eof,svg}', dest: 'dist/fonts/'},

                        // Others
                        {expand: true, cwd: 'src/vendor/kendo/', src: '**/**', dest: 'dist/vendor/kendo/'}
                    ]
                },
                main: {
                    files: [
                        {expand: true, src: 'package.json', dest: 'dist/'},
                        {expand: true, cwd: 'src/img/', src: '**/**', dest: 'dist/img/'},
                        {expand: true, cwd: 'src/app/', src: '**/**', dest: 'dist/app/'},
                        {expand: true, cwd: 'src/css/', src: '**/**', dest: 'dist/css/'}
                    ]
                },
                nwjs: {
                    files: [
                        {expand: true, cwd: 'nwjs', src: '**/**', dest: 'dist/'}
                    ]
                }
            },
            includeSource: {
                options: {
                    basePath: 'dist',
                    baseUrl: '',
                    ordering: 'top-down',
                    templates: {
                        html: {
                            js: '<script src="{filePath}"></script>',
                            css: '<link rel="stylesheet" type="text/css" href="{filePath}" />'
                        }
                    }
                },
                myTarget: {
                    files: {
                        'dist/index.html': 'src/index.tmpl.html'
                    }
                }
            },
            watch: {
                options: {
                    livereload: true,
                },
                js: {
                    files: ['src/app/**/*', 'src/css/**/*'],
                    tasks: ['copy:main', 'includeSource']
                }
            }
        });

        // Load Grunt Modules
        grunt.loadNpmTasks('grunt-contrib-clean');
        grunt.loadNpmTasks('grunt-contrib-copy');
        grunt.loadNpmTasks('grunt-include-source');
        grunt.loadNpmTasks('grunt-contrib-watch');

        // Register Grunt Task
        grunt.registerTask('build', ['clean', 'copy', 'includeSource', 'watch']);
    };
})();