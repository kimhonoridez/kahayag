/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('directives', [
        'formErrorHandler',
        'kygMenuItem',
        'kygUsecase'
    ]);
})();