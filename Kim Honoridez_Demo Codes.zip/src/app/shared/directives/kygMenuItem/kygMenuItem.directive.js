/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('kygMenuItem', [])
        .directive('kygMenuItem', ['$sce', '$state', function ($sce, $state) {
            return {
                restrict: 'E',
                templateUrl: 'app/shared/directives/kygMenuItem/kygMenuItem.html',
                scope: {
                    kygMenuItemConfig: '='
                },
                controller: ['$scope', function ($scope) {
                    $scope.showSubItems = false;
                    //$scope.kygMenuItemConfig.urlPath = $sce.trustAsResourceUrl($scope.kygMenuItemConfig.urlPath);

                    $scope.toggleMenu = function (e, subItems) {
                        if (subItems && subItems.length > 0) {
                            e.preventDefault();
                            angular.element(e.currentTarget.firstElementChild).toggleClass('fa-angle-down');
                            angular.element(e.currentTarget.firstElementChild).toggleClass('fa-angle-up');

                            $scope.showSubItems = !$scope.showSubItems;
                        }
                    };

                    $scope.getHref = function (path) {
                        return $state.href($scope.kygMenuItemConfig.urlPath);
                    };
                }]
            }
        }]);
})();