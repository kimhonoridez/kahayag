/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('formErrorHandler', [])
        .directive('formControl', [function () {
            return {
                restrict: 'C',
                controller: ['$scope', '$element', function ($scope, $element) {
                    console.log($scope);
                    console.log($element[0].validationMessage);

                    if ($element[0]) {
                        $scope.$watch('$element[0].validationMessage', function (newVal) {
                            console.log($element[0].validationMessage);
                        }, true);
                    }
                }]
            };
        }]);
})();
