/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('masterData', [])
        .service('$kygMasterDataSvc', ['$http', function ($http) {
            var masterDataPath = 'app/shared/masterData/masterData.json';
            var masterData = undefined;
            
            this.init = function () {
                $http.get(masterDataPath).then(function (res) {
                    masterData = res.data;
                }, function () {
                    masterData = {};
                });
            };
            
            this.get = function (key) {
                var retVal = [];
                
                if (masterData && masterData[key]) {
                    retVal = angular.copy(masterData[key]);
                }
                
                return retVal;
            };
        }]);
})();