/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('userInfo', [])
        .service('$kygUserInfoSvc', ['$http', '$kygAuthSvc', function ($http, $kygAuthSvc) {
            var userInfo = undefined;

            this.setUserInfo  = function (data) {
                userInfo = data.userDetails;

                // Set User Authorization Resource List
                $kygAuthSvc.setUserAuthResourceList(data.resourceList);
            };

            this.getUserInfo = function () {
                return angular.copy(userInfo);
            };

            this.load = function () {
                var req = {
                    method: 'GET',
                    usecase: 'COMMON',
                    url: 'app/shared/userInfo/mockUserInfo.json'
                };

                return $http(req);
            };

        }]);
})();