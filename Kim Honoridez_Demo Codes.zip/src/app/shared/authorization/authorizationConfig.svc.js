/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('authorizationConfig', [])
        .service('$kygAuthConfigSvc', ['$http', '$kygAuthSvc', function ($http, $kygAuthSvc) {
            var authConfigPath = "app/shared/authorization/authConfig.json";
            var me = this;

            this.setAuthConfig = function (path, successCb, failCb) {
                $http.get(path).then(function (res) {
                    // Set authorization configuration
                    if (res.data && res.data instanceof Object) {
                        $kygAuthSvc.setAuthConfig(res.data);
                    }

                    // If success callback is available, call it
                    if (successCb) {
                        successCb()
                    }
                }, function () {
                    // If fail callback is available, call it
                    if (failCb) {
                        failCb();
                    }
                });
            };

            this.init = function () {
                me.setAuthConfig(authConfigPath);
            };
        }]);
})();