/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
 
(function () {
	'use strict';
	
	angular.module('kahayag')
		.factory('$kygConfigFactory', ['$cookieStore', function ($cookieStore) {
			var item = {};
			
			item.envUrls = {
                onl: 'http://localhost:8000/',
				ofl: 'http://localhost:8001/'
			};

			item.getEnvMode = function () {
				if (!$cookieStore.get('envMode')) {
					// Set online as default
                    $cookieStore.put('envMode', 'online');
				}
                return $cookieStore.get('envMode');
			};

			item.setEnvMode = function (envMode) {
                $cookieStore.put('envMode', envMode);
			};
			
			return item;
		}]);
})();