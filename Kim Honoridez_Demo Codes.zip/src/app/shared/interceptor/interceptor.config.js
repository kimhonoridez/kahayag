/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
 
(function () {
	'use strict';
	
	function httpInterceptor(confFactory, $q, $kygAuthSvc) {
		return {
			request: function (config) {
				var deferred = $q.defer();

				if (config.url.indexOf('.') < 0) {

					// REQUEST LEVEL AUTHORIZATION
					if ($kygAuthSvc.isAuthorized(config.usecase)) {
						var envMode = confFactory.getEnvMode();
						var usecaseMode = $kygAuthSvc.getOriginConfig(config.usecase);
                        config.url = (confFactory.envUrls[usecaseMode.origin[envMode]] || "") + config.url;
					}
					else {
                        config.timout = deferred.promise;
                        deferred.resolve();
					}
				}
				
				return config || $q.when(config);
			},
			response: function (res) {
				// TO DO: Capture possible error messages, etc.

				return res;
			}
		};
	}
	
	angular.module('kahayag')
		.factory('httpInterceptorFactory', ['$kygConfigFactory', '$q', '$kygAuthSvc', httpInterceptor])
		.config(['$httpProvider', function ($httpProvider) {
			$httpProvider.interceptors.push('httpInterceptorFactory');
		}]);
})();