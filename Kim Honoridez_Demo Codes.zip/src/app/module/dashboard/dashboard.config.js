/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('dashboard', [])
        .config(['$stateProvider', function ($stateProvider) {
            $stateProvider
                .state('app.dashboard', {
                    usecase: 'DB-001',
                    url: '/dashboard',
                    templateUrl: 'app/module/dashboard/dashboard.html'
                });
        }]);
})();