/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('layout')
        .controller('mainLayoutCtrl', ['$scope', '$cookieStore', '$timeout', '$kygAuthSvc', 'headerSvc', function ($scope, $cookieStore, $timeout, $kygAuthSvc, headerSvc) {
            var mobileView = 992;

            /**
             * Get window's inner width
             * @returns {Number}
             *  the window's inner width
             */
            $scope.getWidth = function() {
                return window.innerWidth;
            };

            $scope.$watch($scope.getWidth, function(newValue, oldValue) {
                if (newValue >= mobileView) {
                    if (angular.isDefined($cookieStore.get('toggle'))) {
                        $scope.toggle = ! $cookieStore.get('toggle') ? false : true;
                    } else {
                        $scope.toggle = true;
                    }
                } else {
                    $scope.toggle = false;
                }
            });

            $scope.toggleSidebar = function() {
                $scope.toggle = !$scope.toggle;
                $cookieStore.put('toggle', $scope.toggle);
            };

            // STATE LEVEL AUTHORIZATION: Global Checking of state changes and check authorization
            $scope.$on('$stateChangeStart', function(e, toState, toParams, fromState, fromParams) {
                if (!$kygAuthSvc.isAuthorized(toState.usecase)) {
                    e.preventDefault();

                    // Redirect to Unauthorized Page
                }
                else if (headerSvc.setModuleName) {
                    headerSvc.setModuleName($kygAuthSvc.getUsecaseDescription(toState.usecase));
                }
            });

            window.onresize = function() {
                setTimeout(function () {
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                }, 100);
            };
        }]);
})();