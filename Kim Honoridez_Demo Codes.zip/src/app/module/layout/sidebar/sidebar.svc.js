/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('sidebar')
        .service('sidebarSvc', ['$http', function ($http) {

            this.getSidebarConfig = function () {
                return $http.get('app/module/layout/sidebar/sidebarConfig.json');
            };

        }]);
})();