/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('sidebar')
        .controller('sidebarCtrl', ['$scope', 'sidebarSvc', function ($scope, sidebarSvc) {
            var me = this;

            me.menuItems = [];

            function loadMenuItems () {
                sidebarSvc.getSidebarConfig().then(function (res) {
                    me.menuItems = res.data;
                }, function () {
                    me.menuItems = [];
                });
            }
            loadMenuItems ();

            sidebarSvc.refresh = function () {
                loadMenuItems();
            };
        }]);
})();