/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('layout')
        .service('headerSvc', [function () {}]);
})();