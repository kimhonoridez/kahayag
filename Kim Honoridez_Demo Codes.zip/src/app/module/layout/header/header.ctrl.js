/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('layout')
        .controller('headerCtrl', ['$scope', '$state', '$cookieStore', '$kygUserInfoSvc', '$kygConfigFactory', '$kygMasterDataSvc', 'headerSvc', function ($scope, $state, $cookieStore, $kygUserInfoSvc, $kygConfigFactory, $kygMasterDataSvc, headerSvc) {
            var me = this;
            me.moduleName = "Dashboard";
            me.name = $kygUserInfoSvc.getUserInfo().name;
            me.env_mode = undefined;
            me.envList = $kygMasterDataSvc.get('ENV_MODES');

            me.logout = function () {
                // do proper logout before going to entry point screen
                $cookieStore.put('username', '');
                $state.go('splash');
            };

            me.setEnvMode = function (e, mode) {
                e.preventDefault();

                me.env_mode = mode;
                $kygConfigFactory.setEnvMode(mode);
            };

            headerSvc.setModuleName = function (name) {
                me.moduleName = name;
            };

            me.env_mode = $kygConfigFactory.getEnvMode();
        }]);
})();