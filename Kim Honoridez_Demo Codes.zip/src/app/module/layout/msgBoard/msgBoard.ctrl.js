/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('msgBoard')
        .controller('msgBoardCtrl', ['$scope', '$timeout', function ($scope, $timeout) {
            var me = this;

            /**
             * The list of messages
             * @type {Array}
             */
            me.messages = [];

            /**
             * Receive the status/error message to be displayed
             */
            $scope.$on('postMsg', function (e, data) {
                me.messages.push(data);

                $timeout(function () {

                    // Remove message after 5 seconds
                    if (me.messages.length) {
                        me.messages.shift();
                    }
                }, 5000);
            });
        }]);
})();