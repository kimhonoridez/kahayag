/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('customerMgt')
        .controller('customerSearchCtrl', ['$scope', '$kygMasterDataSvc', 'customerSearchSvc', function ($scope, $kygMasterDataSvc, customerSearchSvc) {
            var genderTypeList = $kygMasterDataSvc.get('GENDER');
            var me = this;

            me.searchCriteria = {
                name: "",
                referenceId: undefined
            };

            me.search = function () {
                $scope.custSearchGrid.dataSource.read();
            };

            me.clear = function () {
                me.searchCriteria.name = "";
                me.searchCriteria.referenceId = undefined;
            };

            $scope.gridColumns = [{
                field: "id",
                title: "Reference ID"
            },{
                field: "firstName",
                title: "Customer Name",
                template: "{{ dataItem.firstName + ' ' + dataItem.lastName }}"
            },{
                field: "birthDate",
                title: "Birth Date"
            },{
                field: "gender",
                title: "Gender",
                template: "{{ getGenderName(dataItem.gender) }}"
            }];

            $scope.gridOptions = {
                sortable: true,
                pageable: true
            };

            $scope.custSearchDS = new kendo.data.DataSource({
                transport: {
                    read: function (options) {
                        var data = angular.copy(me.searchCriteria);

                        // Remove name criteria if empty
                        if (!data.name) {
                            delete data.name;
                        }

                        // Remove reference id if empty
                        if (!data.referenceId) {
                            delete data.referenceId;
                        }

                        // Search
                        customerSearchSvc.search(data).then(function (res) {
                            options.success(res.data);
                        }, function () {
                            // TO DO: Display proper error message
                            options.success([]);
                        });
                    }
                },
                pageSize: 50
            });

            $scope.getGenderName = function (id) {
                var retVal = "";

                if (id && genderTypeList) {
                    genderTypeList.forEach(function (item) {
                        if (item.id === id) {
                            retVal = item.name;
                            return;
                        }
                    });
                }

                return retVal;
            }
        }]);
})();