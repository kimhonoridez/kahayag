/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('customerMgt')
        .service('customerSearchSvc', ['$http', function ($http) {

            this.search = function (data) {
                var req = {
                    usecase: 'PM-001',
                    method: 'GET',
                    url: 'custMgt/getCustList',
                    params: data
                };

                return $http(req);
            };
        }]);
})();