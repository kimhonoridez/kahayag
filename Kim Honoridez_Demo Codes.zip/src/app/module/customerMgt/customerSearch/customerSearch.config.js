/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('customerMgt')
        .config(['$stateProvider', function ($stateProvider) {
            $stateProvider
                .state('app.customerSearch', {
                    usecase: 'PM-001',
                    url: '/customerSearch',
                    templateUrl: 'app/module/customerMgt/customerSearch/customerSearch.html'
                });
        }]);
})();