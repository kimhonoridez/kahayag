/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('customerMgt')
        .config(['$stateProvider', function ($stateProvider) {
            $stateProvider
                .state('app.customerRegistration', {
                    usecase: 'PM-002',
                    url: '/customerRegistration',
                    templateUrl: 'app/module/customerMgt/customerRegistration/customerRegistration.html'
                });
        }]);
})();