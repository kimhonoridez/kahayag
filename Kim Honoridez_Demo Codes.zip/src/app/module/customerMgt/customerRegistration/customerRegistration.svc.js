/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('customerMgt')
        .service('customerRegistrationSvc', ['$http', function ($http) {

            this.save = function (data) {
                var req = {
                    usecase: 'PM-002',
                    method: 'POST',
                    url: 'custMgt/save',
                    data: data
                };

                return $http(req);
            };
        }]);
})();