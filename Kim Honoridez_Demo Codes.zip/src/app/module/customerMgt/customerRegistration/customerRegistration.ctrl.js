/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('customerMgt')
        .controller('customerRegistrationCtrl', ['$scope', '$timeout', '$kygMasterDataSvc', 'customerRegistrationSvc', function ($scope, $timeout, $kygMasterDataSvc, customerRegistrationSvc) {
            var me = this;
            me.messageType = 0;
            me.genderTypeList = $kygMasterDataSvc.get('GENDER');

            me.birthDateOptions = {
                max: new Date()
            };

            me.cust = {
                firstName: '',
                lastName: '',
                gender: '',
                birthDate: ''
            };

            me.clear = function () {
                me.cust.firstName = "";
                me.cust.lastName = "";
                me.cust.gender = "";
                me.cust.birthDate = "";
                me.messageType = 0;
            };

            me.register = function () {
                me.messageType = 0;
                // Revalidate form
                if ($('#customerRegistrationForm')[0].checkValidity()) {
                    customerRegistrationSvc.save(me.cust).then(function () {
                        // Clear Form
                        me.clear();

                        // Display success message (TO DO: Messages should be displayed in a centralized manner)
                        me.messageType = 1;
                        $timeout(function () {
                            me.messageType = 0;
                        }, 5000);
                    }, function () {
                        me.messageType = 3;
                    });
                }
                else {
                    me.messageType = 2;
                }
            };
        }]);
})();