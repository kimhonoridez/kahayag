/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('splash', [])
        .config(['$stateProvider', function ($stateProvider) {
            $stateProvider
                .state('splash', {
                    usecase: 'COMMON',
                    url: '/splash',
                    templateUrl: 'app/module/splash/splash.html'
                });
        }]);
})();