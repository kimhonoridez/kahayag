/**
 * @author Kim Honoridez
 * @version 0.0.1
 */
(function () {
    'use strict';

    angular.module('splash')
        .controller('splashCtrl', ['$scope', '$state', '$cookieStore', '$kygUserInfoSvc', function ($scope, $state, $cookieStore, $kygUserInfoSvc) {
            var me = this;
            me.username = $cookieStore.get('username') || "";

            me.submit = function () {
                // check form validity
                if (me.username) {
                    $kygUserInfoSvc.load().then(function (res) {

                        // Mock the name of the user
                        res.data.userDetails.name = me.username;
                        $kygUserInfoSvc.setUserInfo(res.data);
                        $cookieStore.put('username', me.username);

                        $state.go('app.dashboard');
                    }, function () {
                        // display proper error
                        me.requestError = true;
                    });
                }
                else {
                    me.isNameEmpty = true;
                }
            };

            me.clear = function () {
                me.username = "";
            };

            if (me.username) {
                me.submit();
            }
        }]);
})();