/**
 * Created by Kim Honoridez on 15/11/2016.
 */
(function () {
    'use strict';

    angular.module('kahayag', [
            'ui.bootstrap',
            'ui.router',
            'ngCookies',
            'kendo.directives',
            'module',
            'shared'
        ])
        .constant('MsgType', {
            SUCCESS: 0,
            ERROR: 1,
            WARN: 2,
            INFO: 3
        })
        .config(['$compileProvider', function( $compileProvider ) {
            $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|chrome-extension):/);
        }])
        .config(['$stateProvider', '$locationProvider', '$urlRouterProvider', function ($stateProvider, $locationProvider, $urlRouterProvider) {
            $stateProvider
            // main state of the application
                .state('app', {
                    url: '/app',
                    abstract: true,
                    templateUrl: 'app/module/layout/layout.main.html'
                });

            // Disable HTML5 mode
            $locationProvider.html5Mode(false);

            // Set default state
            $urlRouterProvider.otherwise('/splash');
        }])
        .run(['$rootScope', '$kygAuthConfigSvc', '$kygMasterDataSvc', function ($rootScope, $kygAuthConfigSvc, $kygMasterDataSvc) {
            $kygAuthConfigSvc.init();
            $kygMasterDataSvc.init();

            var win = nw.Window.get();
            win.maximize();
        }]);
})();